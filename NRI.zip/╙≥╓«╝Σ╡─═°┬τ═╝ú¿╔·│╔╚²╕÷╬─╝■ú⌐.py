import matplotlib.pyplot as plt
import networkx as nx
import matplotlib as mpl
import numpy as np
import matplotlib.patches

'''1. 读入自己的邻接矩阵并初始化network对象'''
total = np.load('logs/matrix.npy')
G_total = nx.DiGraph()  # 记录所有的edges
G_first = nx.DiGraph()  # 从行开始记录edges
G_second = nx.DiGraph()  # 从列开始记录edges

'''2. 添加所有的节点'''
nodes = ['ploop', 'Nlobe', 'loop', 'Cαhelix', 'Aloop','Clobe']
G_total.add_nodes_from(nodes)
G_first.add_nodes_from(nodes)
G_second.add_nodes_from(nodes)

'''3. 根据读入的邻接矩阵，添加所有的边'''
for i in range(0, len(nodes)):
    for j in range(0, len(nodes)):
        if total[i][j] != 0:
            G_total.add_weighted_edges_from([(nodes[i], nodes[j], total[i][j])])  # 边的起点，终点，权重
            if (i < j):
                G_first.add_weighted_edges_from([(nodes[i], nodes[j], total[i][j])])  # 边的起点，终点，权重
            else:
                G_second.add_weighted_edges_from([(nodes[i], nodes[j], total[i][j])])  # 边的起点，终点，权重
        else:
            pass

'''4. 根据实际情况设置一些参数，决定节点和边的颜色以及大小等'''

# 首先获取边的权重,并可以设定一个阈值，将边的权重值小于阈值的设置成虚线，大于阈值的设置成实线，并根据权重大小决定实线的粗细
# weights = nx.get_edge_attributes(G_total, 'weight')   #这样获得的权值储存在字典里
weights_total = [(u, v, d['weight']) for u, v, d in G_total.edges(data=True)]  # 这样获得的权值储存在一个列表的元组里
elarge_total = [(u, v) for (u, v, d) in G_total.edges(data=True) if d['weight'] > 0.1]
esmall_total = [(u, v) for (u, v, d) in G_total.edges(data=True) if d['weight'] <= 0.1]

weights_first = [(u, v, d['weight']) for u, v, d in G_first.edges(data=True)]  # 这样获得的权值储存在一个列表的元组里
elarge_first = [(u, v) for (u, v, d) in G_first.edges(data=True) if d['weight'] > 0.1]
esmall_first = [(u, v) for (u, v, d) in G_first.edges(data=True) if d['weight'] <= 0.1]

weights_second = [(u, v, d['weight']) for u, v, d in G_second.edges(data=True)]  # 这样获得的权值储存在一个列表的元组里
elarge_second = [(u, v) for (u, v, d) in G_second.edges(data=True) if d['weight'] > 0.1]
esmall_second = [(u, v) for (u, v, d) in G_second.edges(data=True) if d['weight'] <= 0.1]

# 自主设置节点位置
pos_total = nx.circular_layout(G_total)
# pos={'b1':(38,75),'diml':(40,80),'disl':(42,75),
# 'zl':(37,64),'b2':(40,65), 'el':(43,64),
# 'b3':(38,53)}
pos_first = nx.circular_layout(G_first)
# pos={'b1':(38,75),'diml':(40,80),'disl':(42,75),
# 'zl':(37,64),'b2':(40,65), 'el':(43,64),
# 'b3':(38,53)}
pos_second = nx.circular_layout(G_second)
# pos={'b1':(38,75),'diml':(40,80),'disl':(42,75),
# 'zl':(37,64),'b2':(40,65), 'el':(43,64),
# 'b3':(38,53)}

# 节点大小 ，根据节点的进度值设置其大小

node_sizes = []
degrees = G_total.degree()

for size in degrees:  # 度数值是存储在一个列表里
    ss = size[1]  # 原始度值太小，作图看不出来，要乘以一个系数。元组是不允许修改的，因此要先赋值给一个变量，再乘以系数
    ss *= 150
    node_sizes.append(ss)

# 节点和边的颜色，自主设置，边的颜色设置成比节点颜色稍浅
node_colors = ['#189f08', '#f052cb', '#4694e2', '#55b4ae', '#826bd6', '#cda437']
edge_colors = ['#9aca94', '#e8c3df', '#a9cef3', '#aee6e3', '#cac1ed', '#d9c58e']

# 边的颜色，根据该边是由哪个节点发出的，就用哪个节点的颜色
edge_colors_total = []
for weight in weights_total:
    aa = nodes.index(weight[0])
    edge_colors_total.append(edge_colors[aa])

edge_colors_first = []
for weight in weights_first:
    aa = nodes.index(weight[0])
    edge_colors_first.append(edge_colors[aa])

edge_colors_second = []
for weight in weights_second:
    aa = nodes.index(weight[0])
    edge_colors_second.append(edge_colors[aa])

# 设定一个阈值，将边的权重值小于阈值的设置成虚线，大于阈值的设置成实线
elarge_total = [(u, v) for (u, v, d) in G_total.edges(data=True) if d['weight'] > 0.1]
esmall_total = [(u, v) for (u, v, d) in G_total.edges(data=True) if d['weight'] <= 0.1]

elarge_first = [(u, v) for (u, v, d) in G_first.edges(data=True) if d['weight'] > 0.1]
esmall_first = [(u, v) for (u, v, d) in G_first.edges(data=True) if d['weight'] <= 0.1]

elarge_second = [(u, v) for (u, v, d) in G_second.edges(data=True) if d['weight'] > 0.1]
esmall_second = [(u, v) for (u, v, d) in G_second.edges(data=True) if d['weight'] <= 0.1]

# 将权重乘以一定系数，不然边太细
# for i in weights:    #如果权重值是存储在一个字典里，字典遍历的是键
# weights[i]*=10
pp_total = []  # 如果权重值是存储在一个列表里的元组里，直接遍历列表,这样比上一种字典的遍历麻烦多了
for weight in weights_total:
    ww = weight[2]
    ww *= 6  # 乘以一个系数，避免本来的边太细
    pp_total.append(ww)

pp_first = []  # 如果权重值是存储在一个列表里的元组里，直接遍历列表,这样比上一种字典的遍历麻烦多了
for weight in weights_first:
    ww = weight[2]
    ww *= 6  # 乘以一个系数，避免本来的边太细
    pp_first.append(ww)

pp_second = []  # 如果权重值是存储在一个列表里的元组里，直接遍历列表,这样比上一种字典的遍历麻烦多了
for weight in weights_second:
    ww = weight[2]
    ww *= 6  # 乘以一个系数，避免本来的边太细
    pp_second.append(ww)

M_total = G_total.number_of_edges()
edge_alphas_total = [(3 + i) / (M_total + 2) for i in range(M_total)]  # 第二个数字是第一个数字减1，第一个数字设置的越小，透明度差值越大

M_first = G_first.number_of_edges()
edge_alphas_first = [(3 + i) / (M_first + 2) for i in range(M_first)]  # 第二个数字是第一个数字减1，第一个数字设置的越小，透明度差值越大

M_second = G_second.number_of_edges()
edge_alphas_second = [(3 + i) / (M_second + 2) for i in range(M_second)]  # 第二个数字是第一个数字减1，第一个数字设置的越小，透明度差值越大

'''
edges_small=nx.draw_networkx_edges(G_total,pos,
                       edgelist=esmall,
                       style='dashed'
                      )

edges_large=nx.draw_networkx_edges(G_total, pos,
                       edgelist=elarge,
                       #alpha=0.5,
                       #width=list(weights.values()),  #如果权重值是存在一个字典里，应该这样写
                       width=pp,                 #权重值储存在列表里的元组里
                       #arrowsize=10, 
                       #arrowstyle='fancy',
                       arrowstyle='->',
                       edge_color=edge_colors,
                       connectionstyle='arc3, rad = 0.15'
                    )  
'''

# 箭头模式有：Simple，Fancy等
testArrow = matplotlib.patches.ArrowStyle.Simple(head_length=0.4, head_width=.4, tail_width=.1)

fig = plt.figure(figsize=(6, 18), dpi=100)

ax = fig.add_subplot(3, 1, 1)
nodes_total = nx.draw_networkx_nodes(G_total, pos_total,
                                     node_size=node_sizes,
                                     node_color=node_colors,
                                     # alpha=0.5
                                     )
# 由于在networkx中，箭头大小不能像边的粗细或者颜色一样直接传入一个list，只能传入一个数，因此用循环分别画边
for i in range(M_total):
    nx.draw_networkx_edges(G_total, pos_total,
                           node_size=node_sizes,
                           edgelist=[(elarge_total[i][0], elarge_total[i][1])],
                           # alpha=edge_alphas_total[i],
                           # width=list(weights.values()),  #如果权重值是存在一个字典里，应该这样写
                           width=pp_total[i],  # 权重值储存在列表里的元组里
                           arrowsize=pp_total[i] * 6,  # 箭头的大小也和权重有关
                           # arrowstyle='fancy',
                           # arrowstyle='->',
                           arrowstyle=testArrow,
                           edge_color=edge_colors_total[i],
                           connectionstyle='arc3, rad = 0.15',
                           )
nx.draw_networkx_labels(G_total, pos_total,
                        font_size=15
                        )

ax1 = fig.add_subplot(3, 1, 2)

nodes_first = nx.draw_networkx_nodes(G_first, pos_first,
                                     node_size=node_sizes,
                                     node_color=node_colors,
                                     # alpha=0.5
                                     )

# 由于在networkx中，箭头大小不能像边的粗细或者颜色一样直接传入一个list，只能传入一个数，因此用循环分别画边
for i in range(M_first):
    nx.draw_networkx_edges(G_first, pos_first,
                           node_size=node_sizes,
                           edgelist=[(elarge_first[i][0], elarge_first[i][1])],
                           alpha=edge_alphas_first[i],
                           # width=list(weights.values()),  #如果权重值是存在一个字典里，应该这样写
                           width=pp_first[i],  # 权重值储存在列表里的元组里
                           arrowsize=pp_first[i] * 6,  # 箭头的大小也和权重有关
                           # arrowstyle='fancy',
                           # arrowstyle='->',
                           arrowstyle=testArrow,
                           edge_color=edge_colors_first[i],
                           # connectionstyle='arc3, rad = 0.15',
                           )
nx.draw_networkx_labels(G_first, pos_first,
                        font_size=18
                        )

ax2 = fig.add_subplot(3, 1, 3)
nodes_total = nx.draw_networkx_nodes(G_second, pos_second,
                                     node_size=node_sizes,
                                     node_color=node_colors,
                                     # alpha=0.5
                                     )
# 由于在networkx中，箭头大小不能像边的粗细或者颜色一样直接传入一个list，只能传入一个数，因此用循环分别画边
for i in range(M_second):
    nx.draw_networkx_edges(G_second, pos_second,
                           node_size=node_sizes,
                           edgelist=[(elarge_second[i][0], elarge_second[i][1])],
                           alpha=edge_alphas_second[i],
                           # width=list(weights.values()),  #如果权重值是存在一个字典里，应该这样写
                           width=pp_second[i],  # 权重值储存在列表里的元组里
                           arrowsize=pp_second[i] * 6,  # 箭头的大小也和权重有关
                           # arrowstyle='fancy',
                           # arrowstyle='->',
                           arrowstyle=testArrow,
                           edge_color=edge_colors_second[i],
                           # connectionstyle='arc3, rad = 0.15',
                           )
nx.draw_networkx_labels(G_second, pos_second,
                        font_size=18
                        )
# 获取每个节点的总边数
node_degrees = dict(G_total.degree())

# 获取邻接矩阵中的节点顺序
node_order = list(G_total.nodes())

# 将节点度数按真实顺序写入文本文件
with open('node_degrees.txt', 'w') as file:
    file.write('Node\tDegree\n')
    for node in node_order:
        degree = node_degrees[node]
        file.write(f'{node}\t{degree}\n')

print("节点度数已成功按真实顺序写入 node_degrees.txt 文件。")
nx.write_graphml(G_total, "network_total.graphml")
nx.write_graphml(G_first, "network_first.graphml")
nx.write_graphml(G_second, "network_second.graphml")

# plt.show()