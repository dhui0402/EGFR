import py4cytoscape as p4c
nodes = p4c.get_table_columns('node')
edges = p4c.get_table_columns('edge')
print("Node colors:",node_colors)
print(nodes,columns)