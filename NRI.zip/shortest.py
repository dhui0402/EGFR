import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

# 精细同心圆布局，基于大小进行定位并确保所有节点都在内部，调整层密度
def refined_concentric_layout_final_adjustment(G, sizes, scale=1):
    pos = {}
    sorted_nodes = sorted(G.nodes, key=lambda n: sizes[n], reverse=True)
    num_layers = int(np.ceil(np.sqrt(len(sorted_nodes))))

    layer = 1
    count = 0
    print(len(sorted_nodes))
    while count < len(sorted_nodes) - 11:  # 确保外层有足够的节点
        nodes_in_layer = 6 * layer  # 减少内层节点以使其更稀疏
        nodes = sorted_nodes[count:count + nodes_in_layer]
        angle_step = 2 * np.pi / len(nodes)
        for i, node in enumerate(nodes):
            angle = i * angle_step
            r = scale * layer
            pos[node] = (r * np.cos(angle), r * np.sin(angle))
        count += nodes_in_layer
        layer += 1

    # 将剩余的节点放在最外层，使其更紧凑
    remaining_nodes = sorted_nodes[count:]
    print(remaining_nodes)
    angle_step = 2 * np.pi / len(remaining_nodes)
    for i, node in enumerate(remaining_nodes):
        angle = i * angle_step
        r = scale * (layer - 0.8)  # 调整半径使最外层更紧凑
        pos[node] = (r * np.cos(angle), r * np.sin(angle))

    return pos

# 自定义函数在边缘上绘制箭头
def draw_arrows(G, pos, path_edges, ax, arrow_color):
    for edge in path_edges:
        x0, y0 = pos[edge[0]]
        x1, y1 = pos[edge[1]]
        # 调整坐标使箭头出现在节点外部
        arrowprops = dict(arrowstyle='->',
                          color=arrow_color,
                          lw=5,  # 加粗线条和箭头
                          alpha=0.8,  # 使箭头和目标节点颜色一致
                          shrinkA=20, shrinkB=20,  # 增加缩减量以避免箭头嵌入节点
                          connectionstyle='arc3,rad=0.1',
                          mutation_scale = 20)
        ax.annotate('', xy=(x1, y1), xytext=(x0, y0), arrowprops=arrowprops)

# 加载邻接矩阵
file_path = './WT_interactions.npy'
matrix = np.load(file_path)

# 从邻接矩阵创建图对象
G = nx.from_numpy_array(matrix)

# 计算度中心性并转换为节点大小
degree_centrality = nx.degree_centrality(G)
node_sizes = [v * 1500 for v in degree_centrality.values()]  # 调整节点大小

# 生成基于大小定位的精细同心圆布局，确保所有节点都在内部并调整层密度
pos = refined_concentric_layout_final_adjustment(G, degree_centrality, scale=3)

# 统一所有节点的大背景颜色
node_colors = ['#eaeae6' for _ in range(len(G.nodes))]  # 使用浅绿色作为背景颜色

# A_loop、ploop和Nlobe范围
A_loop_range = list(range(75, 87))
ploop_range = list(range(9, 11))
Nlobe_range = list(range(14, 19))

# 设置A_loop、ploop和Nlobe节点的颜色
A_loop_color = '#9ACD32'  # 绿色
ploop_color = '#ADD8E6'  # 蓝色
Nlobe_color = '#DE3163'  # 红色

# 计算节点的权重
def compute_node_weights(G):
    return {node: sum(weight for _, _, weight in G.edges(node, data='weight', default=1)) for node in G.nodes()}

node_weights = compute_node_weights(G)

# 打印A_loop、ploop和Nlobe范围内节点的度中心性和权重
print("A_loop区域节点信息（按度中心性降序）：")
A_loop_info = [(node, degree_centrality[node], node_weights[node]) for node in A_loop_range]
A_loop_info.sort(key=lambda x: (-x[1], -x[2]))
for node, degree, weight in A_loop_info:
    print(f"节点 {node+1} - 度中心性: {degree}, 权重: {weight}")

print("\nploop区域节点信息（按度中心性降序）：")
ploop_info = [(node, degree_centrality[node], node_weights[node]) for node in ploop_range]
ploop_info.sort(key=lambda x: (-x[1], -x[2]))
for node, degree, weight in ploop_info:
    print(f"节点 {node+1} - 度中心性: {degree}, 权重: {weight}")

print("\nNlobe区域节点信息（按度中心性降序）：")
Nlobe_info = [(node, degree_centrality[node], node_weights[node]) for node in Nlobe_range]
Nlobe_info.sort(key=lambda x: (-x[1], -x[2]))
for node, degree, weight in Nlobe_info:
    print(f"节点 {node+1} - 度中心性: {degree}, 权重: {weight}")

# 选择度中心性和权重最高的节点作为起点和终点
start_nodes = [node for node, _, _ in A_loop_info[:3]]
end_nodes_1 = [node for node, _, _ in ploop_info[:3]]
end_nodes_2 = [node for node, _, _ in Nlobe_info[:3]]

# 计算所有可能路径的概率，并选择概率最大的路径
all_paths = []
path_probabilities = []

def find_best_path(start_nodes, end_nodes):
    all_paths = []
    path_probabilities = []
    for start_node in start_nodes:
        for end_node in end_nodes:
            path = nx.shortest_path(G, source=start_node, target=end_node, weight='weight')
            path_probability = np.prod([G[u][v]['weight'] for u, v in zip(path[:-1], path[1:])])
            all_paths.append(path)
            path_probabilities.append(path_probability)
    best_path_index = np.argmax(path_probabilities)
    best_path = all_paths[best_path_index]
    return best_path, all_paths, path_probabilities

best_path_1, all_paths_1, path_probabilities_1 = find_best_path(start_nodes, end_nodes_1)
best_path_2, all_paths_2, path_probabilities_2 = find_best_path(start_nodes, end_nodes_2)

# 打印所有路径的信息和概率（以选定路径的总和为基准）
total_probability_1 = sum(path_probabilities_1)
total_probability_2 = sum(path_probabilities_2)

print("\n所有路径的信息及其概率（到ploop）：")
for path, prob in sorted(zip(all_paths_1, path_probabilities_1), key=lambda x: x[1], reverse=True):
    normalized_prob = prob / total_probability_1
    print(f"路径: {[node+1 for node in path]}, 概率: {normalized_prob}")

print("\n所有路径的信息及其概率（到Nlobe）：")
for path, prob in sorted(zip(all_paths_2, path_probabilities_2), key=lambda x: x[1], reverse=True):
    normalized_prob = prob / total_probability_2
    print(f"路径: {[node+1 for node in path]}, 概率: {normalized_prob}")

# 使用同心圆布局和从中心到边缘的颜色渐变绘制网络图
fig, ax = plt.subplots(figsize=(14, 14))  # 调整图形大小

# 绘制所有节点
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, edgecolors='white', alpha=0.8, ax=ax)  # 较亮的边缘颜色以获得更好的对比
nx.draw_networkx_edges(G, pos, alpha=0.2, edge_color='gray', ax=ax)  # 调整边缘透明度

# 绘制最短路径
# path_edges_1 = list(zip(best_path_1, best_path_1[1:]))
# path_edges_2 = list(zip(best_path_2, best_path_2[1:]))
# draw_arrows(G, pos, path_edges_1, ax, arrow_color='black')
# draw_arrows(G, pos, path_edges_2, ax, arrow_color='blue')
# 绘制最短路径
path_edges_1 = list(zip(best_path_1, best_path_1[1:]))
path_edges_2 = list(zip(best_path_2, best_path_2[1:]))
draw_arrows(G, pos, path_edges_1, ax, arrow_color='#ADD8E6')  # 蓝色，这里修改了颜色值
draw_arrows(G, pos, path_edges_2, ax, arrow_color='#DE3163')  # 红色，这里修改了颜色值

# 在最短路径中绘制节点
nx.draw_networkx_nodes(G, pos, nodelist=best_path_1, node_size=[node_sizes[node] for node in best_path_1], node_color=[node_colors[node] for node in best_path_1], edgecolors='white', ax=ax)
nx.draw_networkx_nodes(G, pos, nodelist=best_path_2, node_size=[node_sizes[node] for node in best_path_2], node_color=[node_colors[node] for node in best_path_2], edgecolors='white', ax=ax)

# 设置起点和终点节点的颜色
nx.draw_networkx_nodes(G, pos, nodelist=A_loop_range, node_size=[node_sizes[node] for node in A_loop_range], node_color=A_loop_color, edgecolors='black', ax=ax)
nx.draw_networkx_nodes(G, pos, nodelist=ploop_range, node_size=[node_sizes[node] for node in ploop_range], node_color=ploop_color, edgecolors='black', ax=ax)
nx.draw_networkx_nodes(G, pos, nodelist=Nlobe_range, node_size=[node_sizes[node] for node in Nlobe_range], node_color=Nlobe_color, edgecolors='black', ax=ax)

# 使用黑色字体颜色绘制标签
labels = {node: str(node + 1) for node in G.nodes()}
nx.draw_networkx_labels(G, pos, font_size=13, labels=labels, font_color='black', ax=ax)  # 调整字体大小

# 设置背景颜色
ax.set_facecolor('#f7f7f7')

plt.title('', fontsize=17)
plt.savefig('WT_shortest_paths_arrows.png')
plt.show()