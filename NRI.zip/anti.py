# 生成残基间相互作用的矩阵

import seaborn as sns 
import matplotlib.pyplot as plt 
import numpy as np 
import pandas as pd 
import os 
import argparse 







parser = argparse.ArgumentParser( 
                    'Visualize the distribution of learned edges between residues.') 
parser.add_argument('--num-residues', type=int, default=137, # 残基数量，这里要根据实际情况进行修改
                    help='Number of residues of the PDB.')
parser.add_argument('--windowsize', type=int, default=95, # 当interval等于100时最大取98，因此其最大值可以认为是interval-2
                    help='window size') 
parser.add_argument('--threshold', type=float, default=0.2, # 可以作图数值的最大值，即小于这个值的数据都不参与作图这个可以适当调整 
                    help='threshold for plotting') 
parser.add_argument('--dist-threshold', type=int, default=12,
                    help='threshold for shortest distance')
parser.add_argument('--filename', type=str, default='logs/out_probs_train.npy', 
                    help='File name of the probs file.') 
parser.add_argument('--output-matrix', type=str, default='WT_interactions.npy', # 添加输出矩阵文件参数
                    help='Output file name for the residue interaction matrix')
parser.add_argument('--output-heatmap', type=str, default='WT_interactions_heatmap.png', # 添加输出热图文件参数
                    help='Output file name for the residue interaction heatmap') 
args = parser.parse_args(args=[]) 
def getEdgeResults(threshold=False): 
    a = np.load(args.filename) 
    b = a[:, :, 1] 
    c = a[:, :, 2] 
    d = a[:, :, 3] 
    # There are four types of edges, eliminate the first type as the non-edge 
    probs = b + c + d 
    # For default residue number 77, residueR2 = 77*(77-1)=5852 residueR2 = args.num_residues * (args.num_residues - 1) 
    residueR2 = args.num_residues * (args.num_residues - 1)
    probs = np.reshape(probs, (args.windowsize, residueR2)) 
    # Calculate the occurrence of edges 
    edges_train = probs / args.windowsize 
    results = np.zeros((residueR2)) 
    for i in range(args.windowsize): 
        results = results + edges_train[i, :] 
    if threshold: 
            # threshold, default 0.6 
        index = results < args.threshold 
        results[index] = 0 
            # Calculate prob for figures 
    edges_results = np.zeros((args.num_residues, args.num_residues)) 
    count = 0
    for i in range(args.num_residues): 
        for j in range(args.num_residues): 
             if not i == j: 
                edges_results[i, j] = results[count] 
                count += 1 
                    
    return edges_results # 获取边缘结果 
edges_results = getEdgeResults(threshold=True) 
            # 保存84个残基的矩阵到 .npy 文件 
np.save(args.output_matrix, edges_results) 
#nx.write_graphml(G_all,"network_all.graphml")
print(f"Saved residue interaction matrix to {args.output_matrix}") 
