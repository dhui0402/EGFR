import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
import argparse

parser = argparse.ArgumentParser(
    'Visualize the distribution of learned edges between residues.')
parser.add_argument('--num-residues', type=int, default=137,
                    help='Number of residues of the PDB.')
parser.add_argument('--windowsize', type=int, default=95,
                    help='window size')
parser.add_argument('--threshold', type=float, default=0.2,
                    help='threshold for plotting')
parser.add_argument('--dist-threshold', type=int, default=12,
                    help='threshold for shortest distance')
parser.add_argument('--filename', type=str, default='logs/out_probs_train.npy',
                    help='File name of the probs file.')
args = parser.parse_args()


def getEdgeResults(threshold=False):
    a = np.load(args.filename)
    b = a[:, :, 1]
    c = a[:, :, 2]
    d = a[:, :, 3]

    # There are four types of edges, eliminate the first type as the non-edge
    probs = b+c+d
    # For default residue number 77, residueR2 = 77*(77-1)=5852
    residueR2 = args.num_residues*(args.num_residues-1)
    probs = np.reshape(probs, (args.windowsize, residueR2))

    # Calculate the occurence of edges
    edges_train = probs/args.windowsize

    results = np.zeros((residueR2))
    for i in range(args.windowsize):
        results = results+edges_train[i, :]

    if threshold:
        # threshold, default 0.6
        index = results < (args.threshold)
        results[index] = 0

    # Calculate prob for figures
    edges_results = np.zeros((args.num_residues, args.num_residues))
    count = 0
    for i in range(args.num_residues):
        for j in range(args.num_residues):
            if not i == j:
                edges_results[i, j] = results[count]
                count += 1
            else:
                edges_results[i, j] = 0

    return edges_results


def getDomainEdges(edges_results, domainName):

    if domainName == 'ploop':
        startLoc = 9
        endLoc = 11
    elif domainName == 'Nlobe':
        startLoc = 14
        endLoc = 19
    elif domainName == 'loop':
        startLoc = 21
        endLoc = 26
    elif domainName == 'Chelix':
        startLoc = 27
        endLoc = 32
    elif domainName == 'Aloop':
        startLoc = 75
        endLoc = 87
   

    edges_results_ploop = edges_results[9:11, startLoc:endLoc]   #用切片取构域，这里要根据实际情况进行修改
    edges_results_Nlobe = edges_results[14:19, startLoc:endLoc]
    edges_results_loop = edges_results[21:26, startLoc:endLoc]
    edges_results_Chelix = edges_results[27:32, startLoc:endLoc]
    edges_results_Aloop= edges_results[75:87, startLoc:endLoc]
    

    edge_num_ploop = edges_results_ploop.sum(axis=0)
    edge_num_Nlobe = edges_results_Nlobe.sum(axis=0)
    edge_num_loop = edges_results_loop.sum(axis=0)
    edge_num_Chelix = edges_results_Chelix.sum(axis=0)
    edge_num_Aloop = edges_results_Aloop.sum(axis=0)
   

    if domainName == 'ploop':
        edge_average_ploop = 0
    else:
        edge_average_ploop = edge_num_ploop.sum(axis=0)/(2*(endLoc-startLoc))
    if domainName == 'Nlobe':
        edge_average_Nlobe = 0
    else:
        edge_average_Nlobe = edge_num_Nlobe.sum(axis=0)/(5*(endLoc-startLoc))
    if domainName == 'loop':
        edge_average_loop = 0
    else:
        edge_average_loop = edge_num_loop.sum(axis=0)/(5*(endLoc-startLoc))
    if domainName == 'Chelix':
        edge_average_Chelix = 0
    else:
        edge_average_Chelix = edge_num_Chelix.sum(axis=0)/(5*(endLoc-startLoc)) #这里的数字代表这个结构域的残基数量，也要根据实际情况进行修改
    if domainName == 'Aloop':
        edge_average_Aloop = 0
    else:
        edge_average_Aloop = edge_num_Aloop.sum(axis=0)/(12*(endLoc-startLoc))
    
   
    edges_to_all = np.hstack((edge_average_ploop, edge_average_Nlobe,
                             edge_average_loop, edge_average_Chelix, edge_average_Aloop))
    return edges_to_all


# Load distribution of learned edges
edges_results_visual = getEdgeResults(threshold=True)
# Step 1: Visualize results
ax = sns.heatmap(edges_results_visual, linewidth=0.5,
                 cmap="Blues", vmax=1.0, vmin=0.0)
plt.savefig('logs/probs2.png', dpi=600)
# plt.show()
plt.close()

# Step 2: Get domain specific results
# According to the distribution of learned edges between residues, we integrated adjacent residues as blocks for a more straightforward observation of the interactions.
# For example, the residues in SOD1 structure are divided into seven domains (β1, diml, disl, zl, β2, el, β3).

edges_results = getEdgeResults(threshold=False)
# SOD1 specific:
ploop = getDomainEdges(edges_results, 'ploop')
Nlobe = getDomainEdges(edges_results, 'Nlobe')
loop = getDomainEdges(edges_results, 'loop')
Chelix = getDomainEdges(edges_results, 'Chelix')
Aloop= getDomainEdges(edges_results, 'Aloop')
edges_results = np.vstack((ploop,Nlobe,loop,Chelix,Aloop))

# print(edges_results)
edges_results_T = edges_results.T
index = edges_results_T < (args.threshold)
edges_results_T[index] = 0

# Visualize
ax = sns.heatmap(edges_results_T, linewidth=1,
                 cmap="Blues", vmax=1.0, vmin=0.0)
ax.set_ylim([7, 0])
plt.savefig('logs/edges_domain2.png', dpi=600)
# plt.show()
plt.close()
